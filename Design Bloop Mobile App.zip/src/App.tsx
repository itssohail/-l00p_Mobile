import { useRef, useState, type ButtonHTMLAttributes, type ReactNode } from "react";

type Screen = "home" | "save" | "library" | "plan" | "you" | "reader";
type Theme = "light" | "dark";
type IconName =
  | "home"
  | "library"
  | "plus"
  | "calendar"
  | "user"
  | "clock"
  | "search"
  | "chevron"
  | "play"
  | "check"
  | "spark"
  | "sun"
  | "moon"
  | "undo"
  | "book";

const reads = [
  {
    source: "Substack",
    sourceMark: "S",
    date: "Saved today",
    title: "On keeping a notebook you actually return to",
    summary: "A small practice for noticing more and holding on to less.",
    meta: "8 min read",
    reminder: "7:30 PM",
    art: "notebook",
  },
  {
    source: "Medium",
    sourceMark: "M",
    date: "Saved yesterday",
    title: "The quiet architecture of a good morning",
    summary: "Why a gentle beginning can change the shape of an entire day.",
    meta: "6 min read",
    reminder: "8:15 PM",
    art: "window",
  },
  {
    source: "YouTube",
    sourceMark: "▶",
    date: "Saved Monday",
    title: "A tour of an artist’s tiny coastal studio",
    summary: "Light, objects, and the rituals behind a daily creative practice.",
    meta: "12 min watch",
    reminder: "Sat",
    art: "coast",
  },
];

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    home: <><path d="M3 10.5 12 3l9 7.5" /><path d="M5.5 9.5V21h13V9.5M9.5 21v-7h5v7" /></>,
    library: <><path d="M5 4h3v16H5zM10.5 4h3v16h-3zM16 5l3-.8 3.6 14.7-3 .8z" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M8 3v4M16 3v4M3 10h18" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4.5 21a7.5 7.5 0 0 1 15 0" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></>,
    search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 5 5" /></>,
    chevron: <path d="m9 5 7 7-7 7" />,
    play: <path d="m9 7 8 5-8 5z" />,
    check: <path d="m5 12 4.5 4.5L19 7" />,
    spark: <><path d="M12 3c.6 4.9 3.1 7.4 8 8-4.9.6-7.4 3.1-8 8-.6-4.9-3.1-7.4-8-8 4.9-.6 7.4-3.1 8-8Z" /></>,
    sun: <><circle cx="12" cy="12" r="3.5" /><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4" /></>,
    moon: <path d="M20 15.2A8.5 8.5 0 0 1 8.8 4a8.5 8.5 0 1 0 11.2 11.2Z" />,
    undo: <><path d="m9 8-4 4 4 4" /><path d="M5 12h8a6 6 0 0 1 6 6" /></>,
    book: <><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H20v17H7.5A3.5 3.5 0 0 0 4 22Z" /><path d="M4 5.5V22M8 7h8M8 11h6" /></>,
  };
  return (
    <svg className="icon" width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

function Button({
  children,
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" }) {
  return (
    <button className={`button button--${variant} ${className}`} {...props}>
      {children}
    </button>
  );
}

function Chip({
  children,
  selected,
  onClick,
}: {
  children: ReactNode;
  selected?: boolean;
  onClick?: () => void;
}) {
  return (
    <button className={`chip ${selected ? "chip--selected" : ""}`} onClick={onClick}>
      {children}
    </button>
  );
}

function SourceBadge({ label, large = false }: { label: string; large?: boolean }) {
  const mark = label.charAt(0);
  return <span className={`source-badge source-badge--${label.toLowerCase()} ${large ? "source-badge--large" : ""}`}>{mark}</span>;
}

function LinkCard({
  item,
  finished = false,
  onOpen,
}: {
  item: (typeof reads)[number];
  finished?: boolean;
  onOpen?: () => void;
}) {
  const [offset, setOffset] = useState(0);
  const startX = useRef(0);
  const dragging = useRef(false);
  const handlePointerDown = (event: React.PointerEvent) => {
    dragging.current = true;
    startX.current = event.clientX;
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const handlePointerMove = (event: React.PointerEvent) => {
    if (!dragging.current) return;
    setOffset(Math.max(-92, Math.min(92, event.clientX - startX.current)));
  };
  const handlePointerUp = () => {
    dragging.current = false;
    setOffset(offset > 38 ? 82 : offset < -38 ? -82 : 0);
  };
  return (
    <div className="swipe-card">
      <div className="swipe-action swipe-action--read"><Icon name="book" size={18} /><span>Read now</span></div>
      <div className="swipe-action swipe-action--plan"><Icon name="clock" size={18} /><span>Reschedule</span></div>
      <article
        className={`link-card ${finished ? "link-card--finished" : ""}`}
        style={{ transform: `translateX(${offset}px)` }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onDoubleClick={onOpen}
      >
        <div className="link-card__body">
          <div className="source-line">
            <SourceBadge label={item.source} />
            <span>{item.source}</span>
            <span className="dot-separator">·</span>
            <span className="muted">{item.date}</span>
          </div>
          <div className="link-title">{item.title}</div>
          <p className="link-summary">{item.summary}</p>
          <div className="link-meta">
            {finished ? (
              <span className="finished-label"><Icon name="check" size={14} /> Finished. Nice.</span>
            ) : (
              <>
                <span>{item.meta}</span>
                <span className="reminder-time"><span className="amber-dot" />{item.reminder}</span>
              </>
            )}
          </div>
        </div>
        <div className={`thumbnail thumbnail--${item.art}`} aria-label="" />
      </article>
    </div>
  );
}

function PageHeader({ title, eyebrow }: { title: string; eyebrow?: string }) {
  return (
    <header className="page-header">
      {eyebrow && <div className="eyebrow">{eyebrow}</div>}
      <div className="page-title">{title}</div>
    </header>
  );
}

function BottomNav({
  active,
  onNavigate,
}: {
  active: Screen;
  onNavigate: (screen: Screen) => void;
}) {
  const item = (screen: Screen, label: string, icon: IconName) => (
    <button
      className={`tab-item ${active === screen ? "tab-item--active" : ""}`}
      onClick={() => onNavigate(screen)}
      aria-label={label}
    >
      <Icon name={icon} size={21} />
      <span>{label}</span>
    </button>
  );
  return (
    <nav className="bottom-nav">
      {item("home", "Home", "home")}
      {item("library", "Library", "library")}
      <button className="save-tab" onClick={() => onNavigate("save")} aria-label="Save a link">
        <Icon name="plus" size={24} />
        <span>Save</span>
      </button>
      {item("plan", "Plan", "calendar")}
      <button className={`tab-item ${active === "you" ? "tab-item--active" : ""}`} onClick={() => onNavigate("you")} aria-label="You">
        <Icon name="user" size={21} />
        <span>You</span>
      </button>
    </nav>
  );
}

function HomeScreen({
  onNavigate,
  theme,
  onToggleTheme,
}: {
  onNavigate: (screen: Screen) => void;
  theme: Theme;
  onToggleTheme: () => void;
}) {
  const [filter, setFilter] = useState<"tonight" | "all" | "read">("tonight");
  const isEmpty = new URLSearchParams(window.location.search).get("state") === "empty";
  return (
    <div className="screen">
      <div className="scroll-area">
        <header className="brand-header">
          <div className="wordmark">bloop<span className="wordmark-dot">.</span></div>
          <div className="header-actions">
            <button className="theme-toggle" onClick={onToggleTheme} aria-label={`Switch to ${theme === "light" ? "dark" : "light"} theme`}>
              <Icon name={theme === "light" ? "moon" : "sun"} size={19} />
            </button>
            <button className="avatar" onClick={() => onNavigate("you")} aria-label="Open profile">AM</button>
          </div>
        </header>

        <div className="segmented-tabs" aria-label="Saved link filters">
          {[
            ["tonight", "For tonight"],
            ["all", "All saved"],
            ["read", "Read"],
          ].map(([value, label]) => (
            <button
              key={value}
              className={filter === value ? "segment segment--active" : "segment"}
              onClick={() => setFilter(value as typeof filter)}
            >
              {label}
            </button>
          ))}
        </div>

        {filter === "tonight" && isEmpty && (
          <div className="home-empty">
            <svg viewBox="0 0 120 100" aria-hidden="true">
              <path d="M25 24h56a10 10 0 0 1 10 10v48H35a10 10 0 0 1-10-10V24Z" />
              <path d="M35 18h56a10 10 0 0 1 10 10v44M43 40h38M43 52h29" />
              <circle cx="91" cy="72" r="15" />
              <path d="M91 65v14M84 72h14" />
            </svg>
            <div className="empty-state__title">Nothing saved yet.</div>
            <p>Save your first link.</p>
            <Button onClick={() => onNavigate("save")}>Save a link</Button>
          </div>
        )}
        {filter === "tonight" && !isEmpty && (
          <>
            <section className="reading-hour">
              <div className="reading-hour__icon">
                <svg className="progress-ring" viewBox="0 0 44 44" aria-hidden="true">
                  <circle className="progress-ring__track" cx="22" cy="22" r="19" />
                  <circle className="progress-ring__value" cx="22" cy="22" r="19" />
                </svg>
                <Icon name="clock" size={18} />
              </div>
              <div className="reading-hour__copy">
                <div className="card-label">Your reading hour</div>
                <div className="reading-time">Tonight, 7:30 PM</div>
                <div className="card-subtext">Starts in 2h 40m · 3 reads</div>
              </div>
              <Button className="start-button" onClick={() => onNavigate("reader")}><Icon name="play" size={15} />Start</Button>
            </section>
            <div className="section-heading">
              <div>Waiting for you</div>
              <span>3 reads</span>
            </div>
            <div className="feed">
              {reads.map((read) => <LinkCard key={read.title} item={read} onOpen={() => onNavigate("reader")} />)}
            </div>
            <div className="feed-closing">That&apos;s all for tonight.</div>
          </>
        )}
        {filter === "all" && (
          <>
            <div className="section-heading section-heading--spaced"><div>All saved</div><span>18 links</span></div>
            <div className="feed">{reads.map((read) => <LinkCard key={read.title} item={read} />)}</div>
          </>
        )}
        {filter === "read" && (
          <>
            <div className="quiet-message"><span>Finished gently, kept here.</span></div>
            <div className="feed"><LinkCard item={reads[2]} finished /></div>
          </>
        )}
      </div>
      <BottomNav active="home" onNavigate={onNavigate} />
    </div>
  );
}

function SaveScreen({
  onNavigate,
  onSaved,
}: {
  onNavigate: (screen: Screen) => void;
  onSaved: () => void;
}) {
  const [reminder, setReminder] = useState("Tonight");
  return (
    <div className="screen">
      <div className="scroll-area save-scroll">
        <div className="modal-header">
          <button className="text-button" onClick={() => onNavigate("home")}>Cancel</button>
          <span className="modal-title">Save a link</span>
          <span className="header-spacer" />
        </div>
        <div className="preview-image">
          <div className="preview-orb preview-orb--one" />
          <div className="preview-orb preview-orb--two" />
          <div className="preview-caption">The art of paying attention</div>
        </div>
        <div className="source-line save-source">
          <SourceBadge label="Substack" />
          <span>Substack</span>
          <span className="auto-label">Found automatically</span>
        </div>
        <label className="field-label" htmlFor="link-name">Name</label>
        <textarea id="link-name" className="name-input" defaultValue="On keeping a notebook you actually return to" />

        <div className="field-group">
          <div className="field-heading">
            <span>Remind me</span>
            <span className="optional">Choose one</span>
          </div>
          <div className="chip-group">
            {["Tonight", "Tomorrow", "This weekend", "Pick a time"].map((choice) => (
              <Chip key={choice} selected={reminder === choice} onClick={() => setReminder(choice)}>
                {choice}
              </Chip>
            ))}
          </div>
        </div>
        <div className="field-group">
          <label className="field-heading" htmlFor="note">
            <span>Add a note</span><span className="optional">Optional</span>
          </label>
          <textarea id="note" className="note-input" placeholder="What made you want to read this?" />
        </div>
      </div>
      <div className="sticky-action">
        <Button onClick={onSaved}>Save for later</Button>
      </div>
    </div>
  );
}

function Confirmation({ onUndo }: { onUndo: () => void }) {
  return (
    <div className="confirmation">
      <div className="save-origin">
        <div className="ripple ripple--three" />
        <div className="ripple ripple--two" />
        <div className="ripple ripple--one" />
        <div className="confirmation-mark"><Icon name="check" size={25} /></div>
      </div>
      <div className="saved-toast">
        <span className="saved-toast__check"><Icon name="check" size={17} /></span>
        <span><strong>Saved.</strong><small>We’ll bring it back tonight.</small></span>
        <button onClick={onUndo}>Undo</button>
      </div>
    </div>
  );
}

const sources = [
  { name: "Substack", count: 8, scheduled: 2 },
  { name: "Medium", count: 5, scheduled: 1 },
  { name: "YouTube", count: 3, scheduled: 1 },
  { name: "Threads", count: 2, scheduled: 0 },
];

function LibraryScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [query, setQuery] = useState("");
  const visible = sources.filter((source) => source.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="screen">
      <div className="scroll-area safe-top">
        <PageHeader eyebrow="Your collection" title="Library" />
        <label className="search">
          <Icon name="search" size={19} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search saved links" />
        </label>
        <div className="section-heading library-heading"><div>Sources</div><span>{sources.length}</span></div>
        <div className="source-list">
          {visible.map((source) => (
            <button className="source-row" key={source.name}>
              <SourceBadge label={source.name} large />
              <span className="source-row__copy">
                <span className="source-row__name">{source.name}</span>
                <span className="source-row__meta">
                  {source.count} saved{source.scheduled ? ` · ${source.scheduled} scheduled` : ""}
                </span>
              </span>
              <Icon name="chevron" size={18} />
            </button>
          ))}
        </div>
        {visible.length === 0 && (
          <div className="empty-state">
            <div className="empty-state__title">Nothing saved yet.</div>
            <p>Save your first link and it’ll find a quiet home here.</p>
            <Button onClick={() => onNavigate("save")}>Save your first link</Button>
          </div>
        )}
        {visible.length > 0 && (
          <>
            <div className="section-heading recent-heading"><div>Recently saved</div><span>See all</span></div>
            <div className="feed"><LinkCard item={reads[0]} /></div>
          </>
        )}
      </div>
      <BottomNav active="library" onNavigate={onNavigate} />
    </div>
  );
}

const days = [
  { day: "M", date: "12" },
  { day: "T", date: "13" },
  { day: "W", date: "14" },
  { day: "T", date: "15", today: true },
  { day: "F", date: "16" },
  { day: "S", date: "17" },
  { day: "S", date: "18" },
];

function PlanScreen({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const [selectedDay, setSelectedDay] = useState("15");
  return (
    <div className="screen">
      <div className="scroll-area safe-top">
        <PageHeader eyebrow="October 12–18, 2026" title="Your reading plan" />
        <div className="week-strip">
          {days.map((day) => (
            <button
              key={day.date}
              className={`day ${selectedDay === day.date ? "day--selected" : ""}`}
              onClick={() => setSelectedDay(day.date)}
            >
              <span>{day.day}</span>
              <strong>{day.date}</strong>
              {day.today && <i />}
            </button>
          ))}
        </div>
        <div className="day-heading">
          <div>Thursday, October 15</div>
          <span>14 minutes planned</span>
        </div>
        <div className="timeline">
          <div className="timeline-item">
            <div className="timeline-time">7:30<br /><span>PM</span></div>
            <div className="timeline-line"><i /></div>
            <div className="timeline-card">
              <div className="source-line"><SourceBadge label="Substack" /><span>Substack</span></div>
              <div className="timeline-title">{reads[0].title}</div>
              <span className="timeline-length">8 min read</span>
            </div>
          </div>
          <div className="timeline-item">
            <div className="timeline-time">7:45<br /><span>PM</span></div>
            <div className="timeline-line"><i /></div>
            <div className="timeline-card">
              <div className="source-line"><SourceBadge label="Medium" /><span>Medium</span></div>
              <div className="timeline-title">{reads[1].title}</div>
              <span className="timeline-length">6 min read</span>
            </div>
          </div>
        </div>
        <Button variant="secondary" className="slot-button"><Icon name="plus" size={18} />Add a reading slot</Button>
        <div className="suggestion">
          <div className="suggestion__icon"><Icon name="spark" size={19} /></div>
          <div>
            <div className="suggestion__title">A quiet window</div>
            <p>Tomorrow at 8:00 PM looks open. Enough time for one short read.</p>
          </div>
          <button className="suggestion__action">Add</button>
        </div>
        <button className="why-link">Why this time?</button>
      </div>
      <BottomNav active="plan" onNavigate={onNavigate} />
    </div>
  );
}

function YouScreen({
  onNavigate,
  theme,
  onThemeChange,
}: {
  onNavigate: (screen: Screen) => void;
  theme: Theme;
  onThemeChange: (theme: Theme) => void;
}) {
  const [appearance, setAppearance] = useState<Theme | "auto">(theme);
  const changeAppearance = (value: Theme | "auto") => {
    setAppearance(value);
    if (value !== "auto") onThemeChange(value);
    else onThemeChange(window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  };
  return (
    <div className="screen">
      <div className="scroll-area safe-top">
        <PageHeader eyebrow="Your space" title="You" />
        <div className="profile-card">
          <div className="profile-avatar">AM</div>
          <div>
            <div className="profile-name">Alex Morgan</div>
            <div className="profile-caption">A quiet place for good things.</div>
          </div>
        </div>
        <div className="settings-heading">Preferences</div>
        <div className="appearance-row">
          <div className="appearance-copy">
            <span>Appearance</span>
            <small>Choose how Bloop looks</small>
          </div>
          <div className="appearance-control">
            {(["light", "dark", "auto"] as const).map((value) => (
              <button
                key={value}
                className={appearance === value ? "appearance-option appearance-option--active" : "appearance-option"}
                onClick={() => changeAppearance(value)}
              >
                {value.charAt(0).toUpperCase() + value.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>
      <BottomNav active="you" onNavigate={onNavigate} />
    </div>
  );
}

function ReaderScreen({
  onNavigate,
  onFinished,
}: {
  onNavigate: (screen: Screen) => void;
  onFinished: () => void;
}) {
  return (
    <div className="screen reader">
      <div className="reader-progress"><span /></div>
      <div className="reader-scroll">
        <button className="reader-close" onClick={() => onNavigate("home")} aria-label="Close reading view">×</button>
        <div className="reader-source">SUBSTACK · 8 MIN READ</div>
        <div className="reader-title">On keeping a notebook you actually return to</div>
        <div className="reader-byline">By Mira Chen</div>
        <div className="reader-body">
          <p>A notebook is most useful when it asks almost nothing of you. It doesn’t need a system, a streak, or a perfect first page. It only needs to be close when something catches your attention.</p>
          <p>Start with the details that would otherwise disappear: the shape of light on a familiar wall, a sentence overheard while waiting for coffee, the question that arrived just before sleep.</p>
          <p>The practice is not really about keeping everything. It is about becoming available to what is already here.</p>
        </div>
      </div>
      <div className="reader-bar">
        <Button variant="secondary" onClick={() => onNavigate("plan")}><Icon name="clock" size={17} />Reschedule</Button>
        <Button onClick={onFinished}><Icon name="check" size={17} />Done</Button>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [confirmed, setConfirmed] = useState(false);
  const [theme, setTheme] = useState<Theme>("light");

  const handleSaved = () => {
    setConfirmed(true);
    window.setTimeout(() => {
      setConfirmed(false);
      setScreen("home");
    }, 2600);
  };

  return (
    <main className="app-shell" data-theme={theme}>
      <div className="phone-frame" data-screen={screen}>
        {confirmed ? (
          <Confirmation onUndo={() => { setConfirmed(false); setScreen("save"); }} />
        ) : screen === "home" ? (
          <HomeScreen onNavigate={setScreen} theme={theme} onToggleTheme={() => setTheme(theme === "light" ? "dark" : "light")} />
        ) : screen === "save" ? (
          <SaveScreen onNavigate={setScreen} onSaved={handleSaved} />
        ) : screen === "library" ? (
          <LibraryScreen onNavigate={setScreen} />
        ) : screen === "plan" ? (
          <PlanScreen onNavigate={setScreen} />
        ) : screen === "you" ? (
          <YouScreen onNavigate={setScreen} theme={theme} onThemeChange={setTheme} />
        ) : (
          <ReaderScreen onNavigate={setScreen} onFinished={() => setScreen("home")} />
        )}
      </div>
    </main>
  );
}
